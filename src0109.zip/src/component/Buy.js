import React, { useState, useEffect } from "react";
import CartModal from "./CartModal";

export default function InsectPriceMonitor() {
  const [insects, setInsects] = useState([]); // 곤충 목록
  const [quantities, setQuantities] = useState({}); // 곤충별 수량
  const [cart, setCart] = useState([]); // 장바구니 상태
  const [isCartModalOpen, setIsCartModalOpen] = useState(false); // 장바구니 모달 상태
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false); // 주문 내역 모달 상태
  const [orders, setOrders] = useState([]); // 주문 내역
  const serviceKey = process.env.REACT_APP_API_KEY;

  // 곤충 목록 가져오기
  const fetchInsects = async () => {
    const url = `http://apis.data.go.kr/6430000/mktPrcMntrIdtIstService/getMktPrcMntrIdtIst?serviceKey=${serviceKey}&currentPage=1&perPage=50`;
    try {
      const response = await fetch(url);
      const data = await response.json();
      setInsects(data.body || []);
      setQuantities(
        data.body.reduce((acc, insect) => {
          acc[insect.INSECT_NM] = 1; // 초기 수량은 모두 1로 설정
          return acc;
        }, {})
      );
    } catch (err) {
      console.error(err);
    }
  };

  // 주문 내역 가져오기
  const fetchOrders = async () => {
    const token = localStorage.getItem("authToken");
    if (!token) {
      alert("로그인이 필요합니다.");
      return;
    }
  
    const url = `http://10.125.121.118:8080/shop/getShop`;
  
    try {
      const response = await fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
  
      if (!response.ok) {
        throw new Error(`서버 응답 에러! 상태 코드: ${response.status}`);
      }
  
      const data = await response.json();
  
      if (!Array.isArray(data)) {
        throw new Error("서버 응답 형식이 올바르지 않습니다.");
      }
  
      const formattedOrders = data.map((item) => ({
        ORDER_ID: item.id,
        PRODUCT_NM: item.item,
        QUANTITY: item.quantity,
        UNIT_PRICE: item.price,
        TOTAL_AMOUNT: item.amount,
      }));
  
      setOrders(formattedOrders);
    } catch (err) {
      console.error("주문 내역을 가져오는 중 오류가 발생했습니다:", err.message);
      alert(`주문 내역을 가져오는 중 문제가 발생했습니다. 오류 메시지: ${err.message}`);
    }
  };
  



  // 주문 취소하기
  const cancelOrder = async (orderId) => {
    const token = localStorage.getItem("authToken"); // 로컬 스토리지에서 토큰 가져오기
    if (!token) {
      alert("로그인이 필요합니다.");
      return;
    }
  
    const url = `http://10.125.121.118:8080/shop/deleteShop/${orderId}`;
    try {
      const response = await fetch(url, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, // 토큰 추가
        },
        credentials: "include", // 인증 세션 포함 (필요한 경우)
      });
  
      if (!response.ok) {
        throw new Error(`Failed to cancel order. Status: ${response.status}`);
      }
  
      alert("주문이 취소되었습니다.");
      setOrders((prevOrders) => prevOrders.filter((order) => order.ORDER_ID !== orderId));
    } catch (err) {
      console.error("주문 취소 중 오류가 발생했습니다:", err.message);
      alert("주문 취소 중 오류가 발생했습니다. 다시 시도해주세요.");
    }
  };
  
  

  // 컴포넌트 로드 시 데이터 가져오기
  useEffect(() => {
    fetchInsects();
  }, []);

  const toggleCartModal = () => {
    setIsCartModalOpen((prev) => !prev);
  };

  const toggleOrderModal = async () => {
    if (!isOrderModalOpen) {
      await fetchOrders(); // 모달 열 때 주문 내역 가져오기
    }
    setIsOrderModalOpen((prev) => !prev);
  };

  const increasePageQuantity = (insectName) => {
    setQuantities((prev) => ({
      ...prev,
      [insectName]: prev[insectName] + 1,
    }));
  };

  const decreasePageQuantity = (insectName) => {
    setQuantities((prev) => ({
      ...prev,
      [insectName]: Math.max(1, prev[insectName] - 1), // 최소 수량은 1
    }));
  };

  const addToCart = (insect) => {
    const quantity = quantities[insect.INSECT_NM];
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.INSECT_NM === insect.INSECT_NM);
      if (existingItem) {
        return prevCart.map((item) =>
          item.INSECT_NM === insect.INSECT_NM
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prevCart, { ...insect, quantity }];
    });
    alert(`${insect.INSECT_NM}이(가) 장바구니에 추가되었습니다!`);
  };


  return (
    <div className="container mx-auto p-4 flex flex-col items-center">
      {/* 곤충 목록 */}
      <div className="w-full max-w-4xl">
        <table className="table-auto w-full border-collapse border border-gray-300">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-2 border border-gray-300 w-1/5">곤충 명</th>
              <th className="p-2 border border-gray-300 w-1/5">단위</th>
              <th className="p-2 border border-gray-300 w-1/5">금액</th>
              <th className="p-2 border border-gray-300 w-1/5">수량</th>
              <th className="p-2 border border-gray-300 w-1/5"></th>
            </tr>
          </thead>
          <tbody>
            {insects.map((insect) => (
              <tr key={insect.INSECT_NM} className="border border-gray-300">
                <td className="p-2">{insect.INSECT_NM}</td>
                <td className="p-2">{insect.WT || "정보 없음"}</td>
                <td className="p-2">{insect.AMOUNT}원</td>
                <td className="p-2">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => decreasePageQuantity(insect.INSECT_NM)}
                      className=" px-2 py-1 rounded border "
                    >
                      -
                    </button>
                    <span>{quantities[insect.INSECT_NM]}</span>
                    <button
                      onClick={() => increasePageQuantity(insect.INSECT_NM)}
                      className="  px-2 py-1 rounded border "
                    >
                      +
                    </button>
                  </div>
                </td>
                <td className="p-2">
                  <button
                    onClick={() => addToCart(insect)}
                    className="bg-gray-500 text-white px-2 py-1 rounded hover:bg-gray-600"
                  >
                    담기
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* 버튼들 */}
      <div className="mt-6 flex space-x-4">
        <button
          onClick={toggleCartModal}
          className="border border-black text-black px-6 py-3 rounded"
        >
          장바구니 보기
        </button>
        <button
          onClick={toggleOrderModal}
          className="border border-black text-black px-6 py-3 rounded"
        >
          주문내역 보기
        </button>
      </div>

      {/* 장바구니 모달 */}
      <CartModal
        isOpen={isCartModalOpen}
        onClose={toggleCartModal}
        cart={cart}
        increaseQuantity={(insectName) =>
          setCart((prevCart) =>
            prevCart.map((item) =>
              item.INSECT_NM === insectName
                ? { ...item, quantity: item.quantity + 1 }
                : item
            )
          )
        }
        decreaseQuantity={(insectName) =>
          setCart((prevCart) =>
            prevCart.map((item) =>
              item.INSECT_NM === insectName && item.quantity > 1
                ? { ...item, quantity: item.quantity - 1 }
                : item
            )
          )
        }
        removeFromCart={(insectName) =>
          setCart((prevCart) => prevCart.filter((item) => item.INSECT_NM !== insectName))
        }
      />

      {/* 주문내역 모달 */}
      {isOrderModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-3xl">
            <h2 className="text-xl font-bold mb-4">주문 내역</h2>
            {orders.length === 0 ? (
              <p>주문 내역이 없습니다.</p>
            ) : (
              <table className="table-auto w-full border-collapse border border-gray-300">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="p-2 border border-gray-300">주문 번호</th>
                    <th className="p-2 border border-gray-300">상품 이름</th>
                    <th className="p-2 border border-gray-300">수량</th>
                    <th className="p-2 border border-gray-300">단가</th>
                    <th className="p-2 border border-gray-300">총 금액</th>
                    <th className="p-2 border border-gray-300">작업</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.ORDER_ID} className="border border-gray-300">
                      <td className="p-2">{order.ORDER_ID}</td>
                      <td className="p-2">{order.PRODUCT_NM}</td>
                      <td className="p-2">{order.QUANTITY}</td>
                      <td className="p-2">{order.UNIT_PRICE}원</td>
                      <td className="p-2">{order.TOTAL_AMOUNT}원</td>
                      <td className="p-2">
                        <button
                          onClick={() => cancelOrder(order.ORDER_ID)}
                          className="bg-gray-500 text-white px-2 py-1 rounded hover:bg-gray-600"
                        >
                          주문 취소
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

            )}
            <div className="mt-4 text-right">
              <button
                onClick={toggleOrderModal}
                className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
