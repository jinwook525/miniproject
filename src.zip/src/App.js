import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import { useState } from 'react';
import Header from './component/Header';
import LoginModal from './component/Loginmodal';
import SignModal from './component/Signmodal';
import BoardModal from './component/BoardModal';
import SearchMain from './component/SearchMain';

function App() {
  const [isLoginModalOpen, setLoginModalOpen] = useState(false);
  const [isSignModalOpen, setSignModalOpen] = useState(false);

  console.log('회원가입 모달 상태:', isSignModalOpen);
  return (
    <BrowserRouter>
      <Header
        onLoginClick={() => setLoginModalOpen(true)}
        onSignUpClick={() => {
          console.log('onSignUpClick 호출됨');
          setSignModalOpen(true);
        }}
      />
      <Routes>
        <Route path="/" element={<SearchMain />} />
        <Route
    path="/signup"
    element={
      <SignModal
        isOpen={isSignModalOpen}
        onClose={() => setSignModalOpen(false)}
      />
    }
  />
        <Route path="/board" element={<BoardModal />} />
      </Routes>

      {/* LoginModal은 조건부 렌더링 */}
      {isLoginModalOpen && (
        <LoginModal
          isOpen={isLoginModalOpen}
          onClose={() => setLoginModalOpen(false)}
        />
      )}
    </BrowserRouter>
  );
}

export default App;
